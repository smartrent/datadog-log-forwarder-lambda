from . import SpanTypes


# [TODO] Deprecated, remove when we remove AppTypes
TYPE = SpanTypes.MONGODB

SERVICE = "mongodb"
COLLECTION = "mongodb.collection"
DB = "mongodb.db"
ROWS = "mongodb.rows"
QUERY = "mongodb.query"
