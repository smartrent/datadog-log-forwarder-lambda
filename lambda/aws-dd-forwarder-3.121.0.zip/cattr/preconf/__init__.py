from cattrs.preconf import validate_datetime

__all__ = ["validate_datetime"]
