SERVICE = "mongodb"
COLLECTION = "mongodb.collection"
DB = "mongodb.db"
QUERY = "mongodb.query"
