# Service info
APP = 'vertica'
