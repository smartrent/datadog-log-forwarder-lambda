"""
Standard network tags.
"""

# request targets
TARGET_HOST = 'out.host'
TARGET_PORT = 'out.port'

BYTES_OUT = 'net.out.bytes'
