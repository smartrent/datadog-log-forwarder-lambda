# tags
NAME = 'db.name'     # the database name (eg: dbname for pgsql)
USER = 'db.user'     # the user connecting to the db
ROWCOUNT = 'db.rowcount'  # the rowcount of a query
