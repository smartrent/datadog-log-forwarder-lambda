# Service info
APP = "vertica"
